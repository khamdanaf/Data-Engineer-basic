# Airflow_with_docker_compose
All tools required are composed in compose_file folder. Run compose file using docker compose -f yaml-file-name up example: docker compose -f airflow.yaml up
