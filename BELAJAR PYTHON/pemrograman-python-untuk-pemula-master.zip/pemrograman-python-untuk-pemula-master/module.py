# Belajar Module 

from function import say_hello
from function import total

hello = say_hello("Eko")
print(hello)

hasil = total(1,2,3,4,5)
print(hasil)