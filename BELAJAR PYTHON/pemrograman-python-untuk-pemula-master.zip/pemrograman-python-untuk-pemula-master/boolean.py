# Tipe Data Boolean

menikah = False
jomblo = True

print(menikah)
print(jomblo)