# Belajar Tuple

pelanggan = ("Eko", "Joko", "Andi")

print(pelanggan[0])
print(pelanggan[1])
print(pelanggan[2])