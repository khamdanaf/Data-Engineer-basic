# Tambah
print(1 + 1)

# Kurang
print(10 - 5)

# Bagi
print(10 / 5)

# Kali
print(10 * 5)

# Sisa Bagi
print(10 % 3)