# Operator Perbandingan
# 
# > lebih dari
# < kurang dari
# >= lebih dari sama dengan
# <= kurang dari sama dengan
# == sama dengan
# != tidak sama dengan
# 

print(1 <= 1)
print(10 == 10)
print(10 != 9)

print("eko" == "eko")
print("eko" != "eko")