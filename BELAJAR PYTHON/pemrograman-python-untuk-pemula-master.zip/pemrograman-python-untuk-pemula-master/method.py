# Belajar Membuat Method / Function

nama = []

def print_nama():
    print("=================")
    for data in nama:
        print(data)

nama.append("eko")
print_nama()

nama.append("kurniawan")
print_nama()

nama.append("khannedy")
print_nama()