# Management Kontak

# Menu
1. Daftar Kontak
2. Tambah Kontak
3. Hapus Kontak
4. Cari Kontak

# Data Kontak
- Nama
- Email
- No Telepon