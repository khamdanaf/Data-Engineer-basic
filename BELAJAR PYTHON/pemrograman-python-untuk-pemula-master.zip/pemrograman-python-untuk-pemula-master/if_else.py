# Belajar If Else

menang = False

if menang:
    print("Selamat!")

else:
    print("Silahkan coba lagi!")