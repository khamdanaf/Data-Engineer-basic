# Belajar For Loop

pelanggan = ["eko", "budi", "joko", "andi"]

pelanggan.append("kurniawan")
pelanggan.append("khannedy")

# Mengakses semua nama pelanggan?
for nama in pelanggan:
    print("========================")
    print(f"Nama Pelanggan : {nama}")
    print("========================")