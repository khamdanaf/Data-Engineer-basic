# Belajar List

nama = ["eko", "budi", "andi"]
nama.append("joko")

print(nama[0])
print(nama[1])
print(nama[2])
print(nama[3])

print(len(nama))

nama.remove("budi")

print(nama)
print(nama[0])
print(nama[1])
print(nama[2])