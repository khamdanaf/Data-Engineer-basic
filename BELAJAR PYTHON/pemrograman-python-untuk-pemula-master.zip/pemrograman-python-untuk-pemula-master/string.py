# Belajar String

nama = "Eko Kurniawan Khannedy"
kota = 'Jakarta'
alamat = 'Jalan Raya Bla Bla Bla'

nama_depan = "Eko"
nama_belakang = "Khannedy"
nama_lengkap = nama_depan + " " + nama_belakang

print(nama_lengkap)