# Belajar Input Number

print("Angka Pertama : ")
a = int( input() )

print("Angka Kedua : ")
b = int(input())

hasil = a + b 
print(f"{a} + {b} = {hasil}")