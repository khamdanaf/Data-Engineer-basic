# Belajar Break

while True:
    data = input("Data : ")
    if data == "x":
        break 
    print(data)