hello = "Selamat Datang"

print(hello)

print(hello)

print(hello)

hello = "Hello Python"

print(hello)

print(hello)