# Belajar String Methods
# https://docs.python.org/3.7/library/stdtypes.html#string-methods

nama = "eko kurniawan khannedy"
print(nama)
print(nama.upper())
print(nama.capitalize())
print(nama.title())
print(nama.split(" "))