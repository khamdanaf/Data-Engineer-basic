# ini adalah komentar

print("Hello") # komentar di ujung