print("Hello World")

print("Selamat Belajar Python")