# Belajar While-Loop

data = ""

while data != "x":
    print("masuk perulangan")
    data = input("data : ")