# Belajar If-Statement

orang = 1000
zombie = 100

if orang < zombie:
    print("Kabur, dunia mau kiamat")

if orang > zombie:
    print("Mari basmi zombie")

if orang == zombie:
    print("Mari bersiap berperang")
