nama_depan = "Eko"
nama_tengah = "Kurniawan"
nama_belakang = "Khannedy"

sapa = f"Halo {nama_depan} {nama_tengah} {nama_belakang}"

print(sapa)
