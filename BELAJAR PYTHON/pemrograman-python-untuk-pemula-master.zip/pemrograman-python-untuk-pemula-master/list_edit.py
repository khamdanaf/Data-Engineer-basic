# Membuat List
nama = ["eko", "budi", "andi"]

# Menambah Data ke List
nama.append("joko")

# Mengakses List
nama[0]

# Menghapus Data dari List
nama.remove("budi")

# Mengubah Data di List
print(nama)
nama[0] = "kurniawan"
print(nama)