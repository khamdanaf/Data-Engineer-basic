# Belajar Range

# nomor = [1,2,3,4,5,6,7,8,9,10]

for no in range(1, 11):
    print(no)