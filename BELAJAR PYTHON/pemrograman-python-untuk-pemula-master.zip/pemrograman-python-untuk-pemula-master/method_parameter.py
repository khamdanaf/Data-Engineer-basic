# Belajar Method Parameter

def say_hello(first_name, last_name):
    print(f"Hello {first_name} {last_name}")

say_hello("Eko", "Kurniawan")
say_hello("Joko", "Morro")