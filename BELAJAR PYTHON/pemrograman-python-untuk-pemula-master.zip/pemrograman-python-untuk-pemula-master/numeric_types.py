# Belajar Numeric Types

# 1. integer
# 2. float
# 3. complex

angka = 1
angka2 = 1.5
total = angka + angka2
print(total)
print(10 / 3)