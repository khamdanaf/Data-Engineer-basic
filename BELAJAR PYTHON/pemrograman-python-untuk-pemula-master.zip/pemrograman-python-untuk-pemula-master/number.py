print(1) # Ini angka
print(1.5) # Ini angka

print("1") # Ini Teks