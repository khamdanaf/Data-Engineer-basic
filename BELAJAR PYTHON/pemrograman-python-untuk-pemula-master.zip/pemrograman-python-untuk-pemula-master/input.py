# Belajar Input Data

print("Silahkan masukkan nama : ")
nama = input()

print(f"Hello {nama}, Selamat Datang")